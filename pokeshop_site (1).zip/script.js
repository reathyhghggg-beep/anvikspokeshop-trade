const pokemonCards = [
    {id:1,title:"Eevee V",set:"SWSH065",image:"https://images.tcgplayer.com/fit/filtered/300x410/db/9f/db9f3b51-f8e8-4a3b-8aab-8e18e9c8e5d1.jpg"},
    {id:2,title:"Lycanroc V",set:"081/203",image:"https://images.tcgplayer.com/fit/filtered/300x410/d6/aa/d6aa9a9e-3e5e-4e5d-8d3e-5e5d8e5d8e5d.jpg"},
    {id:3,title:"Lugia V",set:"SWSH301",image:"https://images.tcgplayer.com/fit/filtered/300x410/0a/1b/0a1b2c3d-4e5f-6a7b-8c9d-0e1f2a3b4c5d.jpg"}
];

let currentCard = null;

document.addEventListener("DOMContentLoaded", () => {
    loadCards();
    setupModal();
    setupSchedule();
});

function loadCards() {
    const grid = document.getElementById("cardsGrid");
    pokemonCards.forEach(card => {
        const div = document.createElement("div");
        div.className = "card";
        div.innerHTML = `
            <img src="${card.image}">
            <h3>${card.title}</h3>
            <p>${card.set}</p>
        `;
        div.onclick = () => openCard(card);
        grid.appendChild(div);
    });
}

function openCard(card) {
    currentCard = card;
    document.getElementById("cardModal").style.display = "block";
    document.getElementById("modalCardImage").src = card.image;
    document.getElementById("modalCardTitle").innerText = card.title;
}

function setupModal() {
    document.querySelector(".close").onclick = () => closeModal();

    document.getElementById("tradeBtn").onclick = () => showTab("trade");
    document.getElementById("buyBtn").onclick = () => showTab("buy");

    document.getElementById("tradeSubmit").onclick = () => {
        alert("Trade sent!");
        closeModal();
    };

    document.getElementById("buySubmit").onclick = () => {
        alert("Buy offer sent!");
        closeModal();
    };
}

function showTab(type) {
    document.getElementById("tradeForm").classList.add("hidden");
    document.getElementById("buyForm").classList.add("hidden");

    if (type === "trade") document.getElementById("tradeForm").classList.remove("hidden");
    if (type === "buy") document.getElementById("buyForm").classList.remove("hidden");
}

function closeModal() {
    document.getElementById("cardModal").style.display = "none";
}

function setupSchedule() {
    document.getElementById("scheduleForm").addEventListener("submit", e => {
        e.preventDefault();
        alert("Meeting scheduled!");
        e.target.reset();
    });
}
