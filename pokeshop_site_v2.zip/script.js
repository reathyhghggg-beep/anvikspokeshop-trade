const pokemonCards=[
{id:1,title:"Eevee V",set:"SWSH065",image:"https://placehold.co/300x410?text=Eevee"},
{id:2,title:"Lycanroc V",set:"081/203",image:"https://placehold.co/300x410?text=Lycanroc"},
{id:3,title:"Lugia V",set:"SWSH301",image:"https://placehold.co/300x410?text=Lugia"}
];

let current=null;

let trades=JSON.parse(localStorage.getItem("trades")||"[]");
let buys=JSON.parse(localStorage.getItem("buys")||"[]");

document.addEventListener("DOMContentLoaded",()=>{
load();
setup();
});

function load(){
const g=document.getElementById("cardsGrid");
pokemonCards.forEach(c=>{
let d=document.createElement("div");
d.className="card";
d.innerHTML=`<img src="${c.image}"><h3>${c.title}</h3>`;
d.onclick=()=>open(c);
g.appendChild(d);
});
}

function open(c){
current=c;
document.getElementById("cardModal").style.display="block";
document.getElementById("modalCardImage").src=c.image;
document.getElementById("modalCardTitle").innerText=c.title;
}

function setup(){
document.querySelector(".close").onclick=()=>document.getElementById("cardModal").style.display="none";

document.getElementById("tradeBtn").onclick=()=>show("trade");
document.getElementById("buyBtn").onclick=()=>show("buy");

document.getElementById("tradeSubmit").onclick=()=>{
let v=document.getElementById("tradeInput").value;
trades.push(v);
localStorage.setItem("trades",JSON.stringify(trades));
alert("Trade saved");
};

document.getElementById("buySubmit").onclick=()=>{
let v=document.getElementById("buyInput").value;
buys.push(v);
localStorage.setItem("buys",JSON.stringify(buys));
alert("Buy saved");
};

document.getElementById("scheduleForm").onsubmit=(e)=>{
e.preventDefault();
alert("Scheduled!");
};
}

function show(t){
document.getElementById("tradeForm").classList.add("hidden");
document.getElementById("buyForm").classList.add("hidden");
if(t==="trade")document.getElementById("tradeForm").classList.remove("hidden");
if(t==="buy")document.getElementById("buyForm").classList.remove("hidden");
}

function adminPanel(){
let p=prompt("Enter admin password");
if(p==="1234"){
alert("Trades:\n"+trades.join("\n")+"\n\nBuys:\n"+buys.join("\n"));
}else{
alert("Wrong password");
}
}
