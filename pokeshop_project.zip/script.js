
const pokemonCards=[
{id:1,title:"Eevee V",set:"SWSH065",image:"https://product-images.tcgplayer.com/fit-in/656x656/246708.jpg",price:"$12.45 NM"},
{id:2,title:"Lycanroc V",set:"081/203",image:"https://product-images.tcgplayer.com/fit-in/656x656/223073.jpg",price:"$2.89 NM"},
{id:3,title:"Lugia V",set:"SWSH301",image:"https://product-images.tcgplayer.com/fit-in/656x656/284137.jpg",price:"$18.74 NM"}
];

document.addEventListener("DOMContentLoaded",()=>{
loadCards();
setupModal();
setupAdmin();
});

function loadCards(){
const g=document.getElementById("cardsGrid");
pokemonCards.forEach(c=>{
const d=document.createElement("div");
d.className="card";
d.innerHTML=`<img src="${c.image}"><h3>${c.title}</h3><p>${c.set}</p><p class="card-price">${c.price}</p>`;
d.onclick=()=>openModal(c);
g.appendChild(d);
});
}

function setupModal(){
document.querySelector(".close").onclick=()=>document.getElementById("cardModal").style.display="none";
}

function openModal(c){
document.getElementById("cardModal").style.display="block";
document.getElementById("modalCardImage").src=c.image;
document.getElementById("modalCardTitle").innerText=c.title;
}

function setupAdmin(){
document.getElementById("adminLoginBtn").onclick=()=>{
if(document.getElementById("adminPassword").value==="974955isverycool21"){
document.getElementById("adminPanel").classList.remove("hidden");
}
}
}
